package com.TP;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;

public class AIMap {
	public static final String TAG = "moto";
	
    

	

	public AIMap(){
	
	}
	
	
	public void buildAIMap(Context context){
		

        
		
		return;
	}
	
	public void aiMapDoDraw(Canvas canvas){
		

		
		
		
		
		
		return;
	}

	
  
	
	public void updatAiMap(){
		
        
  
	}
	
	
	
}
