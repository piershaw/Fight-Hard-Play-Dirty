package com.TP;

public class Level {  
	
	public static String whatLevel = "";
	
	public static void setlevel(String lev) {
		whatLevel = lev;
	return;
	}
	
	public static String getlevel() {
		
	return whatLevel;
	}
	
}
