package com.TP;

import java.util.Random;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;

public class ParticleSystem {
	public static final String TAG = "moto";
    private Particle[] mParticles;
    private int PARTICLECOUNT = 20;
    
	public Drawable smoke;
	public Resources res;
	public Rect particlesRect;
	public float pX;
	public float pY;
	
    public ParticleSystem() {
       //mParticles = new Particle[PARTICLECOUNT];

        Random gen = new Random(System.currentTimeMillis());
        for (int i = 0; i < PARTICLECOUNT; i++) {
            mParticles[i] = new Particle(gen, pX, pY);
            pX = mParticles[i].x;
          	pY = mParticles[i].y;
            
           
            
         Log.i(TAG," mParticles " +  mParticles);
        }
    }
    
    
    
	public void buildParticle(Context context){
		res = context.getResources();
		smoke = context.getResources().getDrawable(R.drawable.bigboom);
	return;	
	}
	
	
	public void particleDoDraw(Canvas canvas){
		particlesRect = new Rect((int)pX,(int)pY,(int)pX + 20, (int)pY + 20);
		
		smoke.setBounds(particlesRect);
		smoke.draw(canvas);
		
	return;
	}
	
	
	
}