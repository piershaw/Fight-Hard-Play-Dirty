package com.TP;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.TextView;

public class Player {
	public static final String TAG = "moto";
	private Explode explode1;
	
	public static int playerPoints;
	public static int playerLife = 1000;
	public static int playersLeft = 6;
	
	public static CharSequence playerPointsString;
	public static double vxPlayer = 0;
	public static double vyPlayer = 0;
	public static double playerSpeedX = 0;
	public static double playerSpeedY = 0;
	public static double slide = 0.098;
	
	public static double playerPosX;
	public static double playerPosY;
	public static double playerPosxr;
	public static double playerPosyr;
	public static double playerPosZ;
	
	public static double playerThrust = 0.5;
	public static Rect playerRect;
    public static int playerWidth = 80;
    public static int playerHeight = 80;
    public static double playerBounce = 0.8;
    public int playerAlpha = 255;
    public static int playerHitNum = 0; 
    public double playerTimer = 3.0; 
    
    private boolean reSpawn = false;
    private int weaponsDamage; 
    
    public AnimationDrawable player;
    public Drawable playerDead;
    
    public Drawable playerTarget;
    public static Rect playerTargetRect;
    public static int playerTargetWidth = 50;
    public static int playerTargetHeight = 50;
    public static int playerTargetVisible;
    
    public static boolean playerExplodeIs = false;
    public static boolean playerIsHit = false;
    
    public Paint playerLifeTextPaint;
	public int playerLifeTextPaintAlpha = 0;
	public String lifeString = "";
  
    public Player(){
    	explode1 = new Explode();
    	playerLifeTextPaint = new Paint();
    }
	


public void buildPlayer(Context context){
	
	Resources res = context.getResources();
	
	playerTarget = context.getResources().getDrawable(R.drawable.cross);
	playerDead = context.getResources().getDrawable(R.drawable.copterdead);
	
    player = new AnimationDrawable();
    player.addFrame(res.getDrawable(R.drawable.copter0001), 100);
    player.addFrame(res.getDrawable(R.drawable.copter0002), 100);
    player.addFrame(res.getDrawable(R.drawable.copter0003), 100);
    player.addFrame(res.getDrawable(R.drawable.copter0004), 100);
    player.addFrame(res.getDrawable(R.drawable.copter0005), 100);
    player.addFrame(res.getDrawable(R.drawable.copter0006), 100);
    player.setOneShot(true);
    player.start();
   
    explode1.buildExplode(context);
    
    
	return;
}



public void playerDoDraw(Canvas canvas){

	explode1.explodeDoDraw(canvas);
	
	if(playerExplodeIs){
		playerRect = new Rect((int)playerPosX , (int)playerPosY, (int)playerPosX + playerWidth, (int)playerPosY + playerHeight);
		playerRect.centerX();
		playerRect.centerY();
		playerDead.setBounds(playerRect);
		playerDead.draw(canvas);
	}else{
		playerRect = new Rect((int)playerPosX , (int)playerPosY, (int)playerPosX + playerWidth, (int)playerPosY + playerHeight);
		playerRect.centerX();
		playerRect.centerY();
		player.setBounds(playerRect);
		player.draw(canvas);
		player.run();

	}



playerTargetRect = new Rect((int)GameMain.playerTargetX, (int)GameMain.playerTargetY, (int)GameMain.playerTargetX  + playerTargetWidth, (int)GameMain.playerTargetY + playerTargetHeight);
playerTargetRect.centerX();
playerTargetRect.centerY();
playerTarget.setBounds(playerTargetRect);
playerTarget.setAlpha(playerTargetVisible);
playerTarget.draw(canvas);


playerLifeTextPaint.setARGB(playerLifeTextPaintAlpha, 255, 255, 255);
playerLifeTextPaint.setTextSize(30);
canvas.drawText(lifeString,10,400, playerLifeTextPaint);



//weapon power table
if(playerExplodeIs != true){
	if(playerRect.contains((int)Bullet.cursherBulletX, (int)Bullet.cursherBulletY)){
		setPOD(GameTable.bulletPower);
		playerIsHit = true;
	}else if(playerRect.contains((int)BadCoper1.gBCoper1BulletX,(int)BadCoper1.gBCoper1BulletY)){
		setPOD(GameTable.badChoper1bulletPower);
		playerIsHit = true;
	//}else if(playerRect.contains((int)Ship.towX,(int)Ship.towY)){
		//setPOD(GameTable.towPower);
		//playerIsHit = true;	
	}else{
		playerIsHit = false;
	}
}




return;
}	


public void updatePlayer(){
	
	
  if(playerExplodeIs){
   	lifeString = playersLeft + "more players";
   		explode1.explodeDoDraw = true;
		explode1.explodeX = playerPosX + playerWidth /2 - 100;
		explode1.explodeY = playerPosY + playerHeight /2 - 100;
		explode1.explodeAlpha = 255;
		explode1.explode.start();
		explode1.explode.run();
		playerAlpha -= GameTable.playerAlpha;
		
		//playerLifeTextPaintAlpha = 255;
		  
		 if(playerAlpha <= 0){
			playerAlpha = 0; 
			explode1.explodeDoDraw = false;
			explode1.explodeAlpha = 0;
			explode1.explode.stop();
			playerTimer -= 0.2;
			 if(playerTimer <= 0.0){
				 playerTimer = 3.0;
				 reSpawn = true;
			 }
		 }
	 }else{
		 playerSpeedX += vxPlayer;
		 playerSpeedY += vyPlayer;
		 playerPosY += vyPlayer;
		 vxPlayer *= slide;
		 vyPlayer *= slide; 
		 playerPosX += playerSpeedX;
		 playerPosY += playerSpeedY;
     }  
	 
	 
	 if(reSpawn){
	     	playerAlpha = 255;
	     	playerHitNum = 0;
	     	playerExplodeIs = false;
	     	playersLeft = playersLeft -1;
	     	reSpawn = false;
	 }
	 
	 	if(playerExplodeIs != true){
	 		
	 	     if(playerIsHit){
	 	      	 playerHitNum =  playerHitNum + getPOD(); //% change hit
	 				//upDateBossHitNum -= 1 + weaponsPower; // gui
	 					//Log.i(TAG, "playerHitNum  " + playerHitNum);
	 					if(playerHitNum > playerLife){
	 						playerIsHit  = false;
	 						playerExplodeIs = true;
	 						
	 					}
	 			
	 			}
	 	 	
	 	 	}
	 	   
	 	
	 
        
        if(playersLeft <= 0){
        	GameView.gameOver = true;
        }
      
 
  
  return;
} 

//power of destruction 
public void setPOD(int wep){
	
	//Log.i(TAG, "weaponsDamage   " + weaponsDamage );
	
	switch(wep){
	case 5 :
		weaponsDamage = wep; 
	break;
	
	case 20 :
		weaponsDamage = wep; 
	break;
	
	case 40 :
		weaponsDamage = wep; 
	break;
	
	
	}
	 
return;		
}

public int getPOD(){
return weaponsDamage; 
}

}
