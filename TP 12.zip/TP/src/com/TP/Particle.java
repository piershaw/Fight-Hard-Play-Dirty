package com.TP;

import java.util.Random;

public class Particle {

    // location
    public float x;
    public float y;
    public float z;
   

    public Particle(Random gen, float xv, float yv) {
    	//xv = (float) (Math.random() * 80 + 120);
    	//yv = (float) (Math.random() * 80 + 120);
        this.x = xv;
        this.y = yv;
        this.z = 120;
    }
    
    
    
	
	

	
	

}