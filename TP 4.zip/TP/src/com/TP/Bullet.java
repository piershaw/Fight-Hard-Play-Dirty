package com.TP;


import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.util.Log;

public class Bullet{
	public static final String TAG = "moto";
	
	public int time = 1;
	public int fireSel = 0; 
	
	public MiniGunBullet miniB;
	public MiniGunBullet miniB1;
	public MiniGunBullet miniB2;
	//public MiniGunBullet miniB3;

	
	public MiniGunBullet miniBArray[];
	
	public boolean minGunFire = false;
	public boolean inFlight = false;
	public boolean notInFlight = true;
	
	public double duration = 1.0;
	public static float badCoperUpDateHitNum = 88.5f;
	public boolean badCoperIsHit = false;
	public boolean badCoperIsHitPow = false;
	public boolean badCoper1ExplodeIs = false;
	public boolean updatePlayerScore = false;
	public boolean reSpawn = false;
	
	
	public int eXMin = 320;
	public int eXMax = 0;
	public int eYMin = 480;
	public int eYMax = 0;
	public int superBumbTimer = 255;
	public int superBumbNum = 20;
	public int weaponsDamage;
	
	
	public Explode explode0;
	public Explode explode1;
	public Explode explode2;
	public Explode explode3;
	public Explode explode4;
	public Explode explode5;
	public Explode explode6;
	public Explode explode7;
	public Explode explode8;
	public Explode explode9;
	public Explode explode10;
	public Explode explode11;
	
	public int explodeOffset = -500;
	
	
	public Drawable bullet;
	public Drawable bullet2;
	public Drawable tracer;
	public Drawable smallRocket;
	public Drawable smallRocket2;
	public AnimationDrawable hellFire;
	public Bitmap bitmapTracer;
	
	
	public Drawable m22MissleColloder;
	public Drawable m22MissleColloder1;
	public Drawable m22MissleColloder2;
	public Drawable m22MissleColloder3;
	public Drawable m22MissleColloder4;
	public Drawable m22MissleColloder5;
	public Drawable m22MissleColloder6;
	public Drawable m22MissleColloder7;
	
	public Drawable m22Smoke;
	public Rect m22RectSmoke;
	public double m22SmokeX;
	public double m22SmokeY;
	public double m22SmokeWidth = 20;
	public double m22SmokeHeight = 20;
	public int m22SmokeAlpha = 0;
	public int m22SmokeAlphaNum = 255;

	
	public Bitmap m22Missle;
	public Bitmap m22Missle1;
	public Bitmap m22Missle2;
	public Bitmap m22Missle3;
	public Bitmap m22Missle4;
	public Bitmap m22Missle5;
	public Bitmap m22Missle6;
	public Bitmap m22Missle7;
	
	

	public Drawable cursherBullet;
	public Drawable cursherBullet1;
	public Drawable cursherBullet2;
	
	
	
	
	
	public static double bulletX = 0;
	public static double bulletY = 0;
	public double lastBulletX = 0;
	public double bulletSpeed = 50;
	public boolean showBullet = false;
	public static int showBulletAlpha = 0;
	public String bulletName;
	public boolean reloadedBullet = false;
	private int bulletWidth = 2;
	private int bulletHeight = 80;
	public boolean fireBullet = false; 
	
	public static double bullet2X = 0;
	public static double bullet2Y = 0;
	public double lastBullet2X = 0;
	public double bulletSpeed2 = 50;
	public int showBullet2Alpha = 0;
	public boolean reloadedBullet2 = false;
	private int bullet2Width = 2;
	private int bullet2Height = 80;
	
	
	public static double smallRocketX = 0;
	public static double smallRocketY = 0;
	public double lastsmallRocketX = 0;
	public double smallRocketSpeed = 50;
	public int showsmallRocketAlpha = 0;
	public boolean reloadedsmallRocket = false;
	private int smallRocketWidth = 20;
	private int smallRocketHeight = 20;
	public double smallRocket2X = 0;
	public double smallRocket2Y = 0;
	
	public double lastsmallRocket2X = 0;
	public double smallRocketSpeed2 = 50;
	public int showsmallRocket2Alpha = 0;
	public boolean reloadedsmallRocket2 = false;
	private int smallRocket2Width = 20;
	private int smallRocket2Height = 20;
	
	
	public Rect bulletRect;
	public Rect bullet2Rect;
	public Rect smallRocket2Rect;
	public Rect smallRocketRect;
	public Rect tracerRect;
	public static Rect hellfireRect;
	public Rect cursherBulletRect;
	public Rect cursherBulletRect1;
	public Rect cursherBulletRect2;
	
	
	public int rocketReloadNum;
	public int rocketReloadNum2;
	public String rocketName;

	
	public double tracerX = 0;
	public double tracerY = 0;
	public double tracerSpeed = 6;
	public double tracerXSpeed = 0;
	public double tracerYSpeed = 0;
	public int showtracerAlpha = 0;
	public String tracerName;
	public boolean reloadedtracer = false;
	public int tracerWidth = 12;
	public int tracerHeight = 32;
	public boolean fireTracer = false; 
	public boolean reloadTracer = false; 
	public int tracerReloadNum;
	public double tracerHeading;
	public double tracerDist;
	public double tracerRot;
	

	public static double hellfireX = 0;
	public static double hellfireY = 0;
	public boolean showHellfire = false;
	public int showHellfireAlpha = 0;
	public final String hellfireName = "helfire";
	private int hellfireWidth = 12;
	private int hellfireHeight = 22;
	
	
	
	public static double cursherBulletX = 0;
	public static double cursherBulletY = 0;
	public int showcursherBulletAlpha = 0;
	public int cursherBulletReloadNum;
	public boolean reloadcursherBullet = false; 
	public double cursherBulletXSpeed = 0;
	public double cursherBulletYSpeed = 0;
	
	public static double cursherBulletX1 = 0;
	public static double cursherBulletY1 = 0;
	public int showcursherBulletAlpha1 = 0;
	public int cursherBulletReloadNum1;
	public boolean reloadcursherBullet1 = false; 
	public double cursherBulletXSpeed1 = 0;
	public double cursherBulletYSpeed1 = 0;
	
	public static double cursherBulletX2 = 0;
	public static double cursherBulletY2 = 0;
	public int showcursherBulletAlpha2 = 0;
	public int cursherBulletReloadNum2;
	public boolean reloadcursherBullet2 = false; 
	public double cursherBulletXSpeed2 = 0;
	public double cursherBulletYSpeed2 = 0;
	
	
	public double cursherBulletSpeed = 6;
	public String cursherBulletName;
	public int cursherBulletWidth = 10;
	public int cursherBulletHeight = 10;

	public double cursherBulletHeading;
	public double cursherBulletDist;
	public double cursherBulletRot;
	
	public Rect m22Rect;
	public static double m22X;
	public static double m22Y;
	public double m22XPointer;
	public double m22YPointer;
	public double m22Width = 20;
	public double m22Height = 20;
	public double m22Speed = 0.2;
	public double m22SpeedX = 0;
	public double m22SpeedY = 0;
	public double m22Heading = 0;
	public double m22Rot = 0;
	public double m22radians = 0;
	public double m22Angle = 0;
	public double m22AngleRot = 0;
	public double m22AngleHead = 0;
	public double m22DX;
	public double m22DY;
	public double m22ReloadNum;
	public int m22ReloadTime;
	private int m22SeletorNum = 0;
	public boolean reloadM22 = false;
	public boolean fireM22 = false;
	
	
	
	public double mbX;
	public double mbY;
	public double mbWidth = 20;
	public double mbHeight = 20;
	public double mbSpeed = 10;
	public double mbSpeedX = 0;
	public double mbSpeedY = 0;
	public int mbAlpha = 0;
	public double mbHeading = 0;
	public double mbRot = 0;
	public double mbradians = 0;
	public double mbAngle = 0;
	public double mbAngleRot = 0;
	public double mbAngleHead = 0;
	public double mbDX;
	public double mbDY;
	
	
	
	public boolean fireGb = false;
	public boolean reloadGb = false;
	
	
	public double gravity = 8.58;
	public double friction = 0.98;
	public double bounce = 0.4;
	public double areaBounce = 0.9;
	public static int rot = 0;
 
	
	//public double bulletArrayY[] = new double[8];
	//public double bulletArrayX[] = new double[8];
	
	
	
	public int fireRate;
	public int fireGun;
	
	public double radians;
	
	public int bulletReloadNum;
	
	//public  double playerLOCX = 0;
	//public static double playerLOCY = 0;
	
	public Resources res;
	public MediaPlayer mp;
	
	public Rect clockRect;
	public double clockX = 120;
	public double clockY = 120;
	public double clockWidth = 30;
	public double clockHeight = 30;
	public double clock;	
	public double clockRot = 0;
	public double clockHeading = 0;
	public double clockSpeed = 30;
	public double clockXSpeed = 0;
	public double clockYSpeed = 0;
	

	public Bullet(){
		 fireTracer = false;
		 fireRate = 10;
		 fireGun = 1;
		 tracerReloadNum = 0;
		 bulletReloadNum = 0;
		 rocketReloadNum = 0;
		 rocketReloadNum2 = 0;
		 m22ReloadNum = 0;
		 
		 miniBArray = new MiniGunBullet[3];
		 
		 miniB = new MiniGunBullet();
		 miniB1 = new MiniGunBullet();
		 miniB2 = new MiniGunBullet();
		 //miniB3 = new MiniGunBullet();
		 
		 miniBArray[0] = miniB;
		 miniBArray[1] = miniB1;
		 miniBArray[2] = miniB2;
		 //miniBArray[3] = miniB3;
		 
		
		 
		// on/off
		//bulletName = "single";
		//bulletName = "double";
		//rocketName = "smallRocket";
	
		m22ReloadNum = 1.0;
		
		radians = Math.PI/360;
		tracerRot = tracerHeading * radians;
  		tracerHeading = (tracerRot * 360 / Math.PI);
  		
  		clock = Math.PI/360;
 		clockRot = clockHeading * clock;
 		clockHeading = (clockRot * 360 / Math.PI);
  		
  		
    	m22ReloadTime = 0;
  		m22radians = 360 * 2 / Math.PI;
  		
  		explode0 = new Explode(); 
  		explode1 = new Explode(); 
  		explode2 = new Explode(); 
  		explode3 = new Explode(); 
  		explode4 = new Explode(); 
  		explode5 = new Explode(); 
  		explode6 = new Explode(); 
  		explode7 = new Explode(); 
  		explode8 = new Explode(); 
  		explode9 = new Explode(); 
  		explode10 = new Explode(); 
  		explode11 = new Explode(); 
  		
  		
  		reloadM22Missle();
  		
		reloadCrusherGun();
		reloadCrusherGun1();
		reloadCrusherGun2();
		
			explode0.explodeX = explodeOffset;
			explode0.explodeY = 0;
			
			explode1.explodeX = explodeOffset;
			explode1.explodeY = 0;
			
			explode2.explodeX = explodeOffset;
			explode2.explodeY = 0;
			
			explode3.explodeX = explodeOffset;
			explode3.explodeY = 0;
			
			explode4.explodeX = explodeOffset;
			explode4.explodeY = 0;
			
			explode5.explodeX = explodeOffset;
			explode5.explodeY = 0;
			
			explode6.explodeX = explodeOffset;
			explode6.explodeY = 0;
			
			explode7.explodeX = explodeOffset;
			explode7.explodeY = 0;
			
			explode8.explodeX = explodeOffset;
			explode8.explodeY = 0;
			
			explode9.explodeX = explodeOffset; 
			explode9.explodeY = 0;
			
			explode10.explodeX = explodeOffset;
			explode10.explodeY = 0;
			
			explode11.explodeX = explodeOffset;
			explode11.explodeY = 0;
	}
	
	
	public void buildBullet(Context context){
		res = context.getResources();
		
		explode0.buildExplode(context);  
  		explode1.buildExplode(context);    
  		explode2.buildExplode(context);    
  		explode3.buildExplode(context);   
  		explode4.buildExplode(context);   
  		explode5.buildExplode(context);   
  		explode6.buildExplode(context);   
  		explode7.buildExplode(context);    
  		explode8.buildExplode(context);    
  		explode9.buildExplode(context);   
  		explode10.buildExplode(context);   
  		explode11.buildExplode(context);   
		
		bullet = context.getResources().getDrawable(R.drawable.sbulletlong);
		bullet2 = context.getResources().getDrawable(R.drawable.sbulletlong);
		
	
		
		smallRocket = context.getResources().getDrawable(R.drawable.smallrocket);
		smallRocket2 = context.getResources().getDrawable(R.drawable.smallrocket);
		
		cursherBullet = context.getResources().getDrawable(R.drawable.crusherbullet);
		cursherBullet1 = context.getResources().getDrawable(R.drawable.crusherbullet);
		cursherBullet2 = context.getResources().getDrawable(R.drawable.crusherbullet);
		
		tracer = context.getResources().getDrawable(R.drawable.boxcollider);
		bitmapTracer = BitmapFactory.decodeResource(res,R.drawable.tracer); 
		
		
		m22MissleColloder = context.getResources().getDrawable(R.drawable.boxcolliderm22);
		m22Missle = BitmapFactory.decodeResource(res,R.drawable.hellfire);
		//m22Smoke = context.getResources().getDrawable(R.drawable.smokesmall);
	
		
	
		miniB.buildGBullet(context);
		miniB1.buildGBullet(context);	
		miniB2.buildGBullet(context);
		//miniB3.buildGBullet(context);
	
		
		//hellFire = context.getResources().getDrawable(R.drawable);
		hellFire = new AnimationDrawable();
	    hellFire.addFrame(res.getDrawable(R.drawable.hellfire0001), 100);
	    hellFire.addFrame(res.getDrawable(R.drawable.hellfire0002), 100);
	    hellFire.addFrame(res.getDrawable(R.drawable.hellfire0003), 100);
	    hellFire.addFrame(res.getDrawable(R.drawable.hellfire0004), 100);
	    hellFire.addFrame(res.getDrawable(R.drawable.hellfire0005), 100);
	    hellFire.setOneShot(false);
	        
		mp = MediaPlayer.create(context, R.raw.playershot2);
		// mp.prepare();
	
		
	     
		
		
	 return;
	}
	
	public void bulletDoDraw(Canvas canvas){
		
		clockRect = new Rect((int)clockX,(int)clockY,(int)clockX + (int)clockWidth, (int)clockY + (int)clockHeight);
		
		canvas.save();
		canvas.rotate((float)clockHeading, (float)clockX + (float)clockWidth /2 , (float)clockY + (float)clockHeight /2);
		canvas.restore();

		bulletRect = new Rect((int)bulletX,(int)bulletY,(int)bulletX + bulletWidth, (int)bulletY + bulletHeight);
		bulletRect.centerX();
		bulletRect.centerY();
        
        bullet.setBounds(bulletRect);
        bullet.setAlpha(showBulletAlpha);
        bullet.draw(canvas);
        
        bullet2Rect = new Rect((int)bullet2X,(int)bullet2Y,(int)bullet2X + bullet2Width, (int)bullet2Y + bullet2Height);
		bullet2Rect.centerX();
		bullet2Rect.centerY();
        
        bullet2.setBounds(bullet2Rect);
        bullet2.setAlpha(showBulletAlpha);
        bullet2.draw(canvas);
        
        smallRocketRect = new Rect((int)smallRocketX,(int)smallRocketY,(int)smallRocketX + smallRocketWidth, (int)smallRocketY + smallRocketHeight);
		smallRocketRect.centerX();
		smallRocketRect.centerY();
        
        smallRocket.setBounds(smallRocketRect);
        smallRocket.setAlpha(showsmallRocketAlpha);
        smallRocket.draw(canvas);
        
        smallRocket2Rect = new Rect((int)smallRocket2X,(int)smallRocket2Y,(int)smallRocket2X + smallRocket2Width, (int)smallRocket2Y + smallRocket2Height);
		smallRocket2Rect.centerX();
		smallRocket2Rect.centerY();
        
        smallRocket2.setBounds(smallRocket2Rect);
        smallRocket2.setAlpha(showsmallRocket2Alpha);
        smallRocket2.draw(canvas);
        
       
        tracerRect = new Rect((int)tracerX,(int)tracerY,(int)tracerX + tracerWidth, (int)tracerY + tracerHeight);
		tracerRect.centerX();
		tracerRect.centerY();
        tracer.setBounds(tracerRect);
        tracer.setAlpha(0);
        tracer.draw(canvas);
		
        
        cursherBulletRect = new Rect((int)cursherBulletX,(int)cursherBulletY,(int)cursherBulletX + cursherBulletWidth, (int)cursherBulletY + cursherBulletHeight);
		cursherBulletRect.centerX();
		cursherBulletRect.centerY();
		
		cursherBullet.setBounds(cursherBulletRect);
		cursherBullet.setAlpha(showcursherBulletAlpha);
		cursherBullet.draw(canvas);
		
		cursherBulletRect1 = new Rect((int)cursherBulletX1,(int)cursherBulletY1,(int)cursherBulletX1 + cursherBulletWidth, (int)cursherBulletY1 + cursherBulletHeight);
		cursherBulletRect1.centerX();
		cursherBulletRect1.centerY();
		
		cursherBullet1.setBounds(cursherBulletRect1);
		cursherBullet1.setAlpha(showcursherBulletAlpha1);
		cursherBullet1.draw(canvas);
		
		cursherBulletRect2 = new Rect((int)cursherBulletX2,(int)cursherBulletY2,(int)cursherBulletX2 + cursherBulletWidth, (int)cursherBulletY2 + cursherBulletHeight);
		cursherBulletRect2.centerX();
		cursherBulletRect2.centerY();
		
		cursherBullet2.setBounds(cursherBulletRect2);
		cursherBullet2.setAlpha(showcursherBulletAlpha2);
		cursherBullet2.draw(canvas);
		
		
		
		miniB.bulletGBDoDraw(canvas);
		miniB1.bulletGBDoDraw(canvas);
		miniB2.bulletGBDoDraw(canvas);
		//miniB3.bulletGBDoDraw(canvas);
		
		
		
		m22Rect = new Rect((int)m22XPointer,(int)m22YPointer,(int)m22XPointer + (int)m22Width, (int)m22YPointer + (int)m22Height);
		m22Rect.centerX();
		m22Rect.centerY();
		m22MissleColloder.setBounds(m22Rect);
		m22MissleColloder.setAlpha(0);
		m22MissleColloder.draw(canvas);
		
		/*m22RectSmoke = new Rect((int)m22SmokeX,(int)m22SmokeY,(int)m22SmokeX + (int)m22SmokeWidth, (int)m22SmokeY + (int)m22SmokeHeight);
		m22RectSmoke.centerX();
		m22RectSmoke.centerY();
		m22Smoke.setBounds(m22RectSmoke);
		m22Smoke.setAlpha(m22SmokeAlpha);
		m22Smoke.draw(canvas);*/
		
		if(Player.playerTargetVisible == 255){
		canvas.save();
		canvas.rotate((float) -m22AngleHead, (float)m22XPointer + (float)m22Width /2 , (float)m22YPointer + (float)m22Height /2);
		canvas.drawBitmap(m22Missle, (int)m22XPointer, (int)m22YPointer, null);
		canvas.restore();
		}
		
		//keep this is the tracer
		
		/*canvas.save();
		canvas.rotate((float)tracerHeading, (float)tracerX , (float)tracerY);
		canvas.drawBitmap(bitmapTracer, (int)tracerX, (int)tracerY + 60, null);
		canvas.restore();*/
		
		
		
		hellfireRect = new Rect((int)hellfireX,(int)hellfireY,(int)hellfireX + hellfireWidth, (int)hellfireY + hellfireHeight);
	    hellfireRect.centerX();
	    hellfireRect.centerY();
	        
	    hellFire.setBounds(hellfireRect);
	    hellFire.setAlpha(showHellfireAlpha);
	    hellFire.setVisible(showHellfire,false);
	    hellFire.draw(canvas);
	    
		
	    explode0.explodeDoDraw(canvas);
  		explode1.explodeDoDraw(canvas);   
  		explode2.explodeDoDraw(canvas);   
  		explode3.explodeDoDraw(canvas);   
  		explode4.explodeDoDraw(canvas);  
  		explode5.explodeDoDraw(canvas); 
  		explode6.explodeDoDraw(canvas);   
  		explode7.explodeDoDraw(canvas);   
  		explode8.explodeDoDraw(canvas);   
  		explode9.explodeDoDraw(canvas); 
  		explode10.explodeDoDraw(canvas); 
  		explode11.explodeDoDraw(canvas);
  		
  		
  		
  		
 		 //weapon power table
 	    if(BadCoper1.badCoper1ExplodeIs != true){
 	    
 			if(BadCoper1.badCoper1Rect.intersect(miniB.gBulletRect)){
 				setPOD(GameTable.bulletPower);//mingun
				badCoperUpDateHitNum -= 1 + GameTable.bulletPower;
 				badCoperIsHit = true;
 			}else{
 				badCoperIsHit = false;
 			}
 		}
 	    
 	   //weapon power table
 	    if(BadCoper1.badCoper1ExplodeIs != true){
 	    
 			if(BadCoper1.badCoper1Rect.intersect(miniB1.gBulletRect)){
 				setPOD(GameTable.bulletPower);//mingun
 				badCoperUpDateHitNum -= 1 + GameTable.bulletPower;
 				badCoperIsHit = true;
 			}else{
 				badCoperIsHit = false;
 			}
 		}
 	    
 	    
 	   //weapon power table
 	    if(BadCoper1.badCoper1ExplodeIs != true){
 	    
 			if(BadCoper1.badCoper1Rect.intersect(miniB2.gBulletRect)){
 				setPOD(GameTable.bulletPower);//mingun
 				badCoperUpDateHitNum -= 1 + GameTable.bulletPower;
 				badCoperIsHit = true;
 			}else{
 				badCoperIsHit = false;
 			}
 		}
 	    
 	    
 	   /*//weapon power table
 	    if(BadCoper1.badCoper1ExplodeIs != true){
 	    
 			if(BadCoper1.badCoper1Rect.intersect(miniB3.gBulletRect)){
 				setPOD(GameTable.bulletPower);//mingun
 				badCoperIsHit = true;
 			}else{
 				badCoperIsHit = false;
 			}
 		}*/
 	    
 	    
 	    
 	    
 	    
  		
  		
        //weapon power table
        if(BadCoper1.badCoper1ExplodeIs != true){
			
			if(	BadCoper1.badCoper1Rect.intersect(explode0.explodeRect)){
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;
			}else if(BadCoper1.badCoper1Rect.intersect(explode1.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode2.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode3.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode4.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode5.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode6.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode8.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode9.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode10.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;	
			}else if(BadCoper1.badCoper1Rect.intersect(explode11.explodeRect)){			
				setPOD(GameTable.superBombPower);
				BadCoper1.badCoperIsHit = true;		
			}else{
				//BadCoper1.badCoperIsHit = false;
			}
		}
		
        
        
        
   
    //weapon power table
      if(GameView.shipArray[1].shipHitExplode != true){
		if(explode0.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;
		}else if(explode1.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
    		setPOD(GameTable.superBombPower);
    		GameView.shipArray[1].shipHit = true;	
		}else if(explode2.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode3.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;		
		}else if(explode4.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode5.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode6.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode7.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode8.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode9.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode10.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else if(explode11.explodeRect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[1].shipHit = true;	
		}else{
			GameView.shipArray[1].shipHit = false;
		}
	}
        

	
	
    //weapon power table
    if(GameView.shipArray[2].shipHitExplode != true){
		if(explode0.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;
		}else if(explode2.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
  		setPOD(GameTable.superBombPower);
  		GameView.shipArray[2].shipHit = true;	
		}else if(explode2.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode3.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;		
		}else if(explode4.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode5.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode6.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode7.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode8.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode9.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode10.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else if(explode11.explodeRect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
			setPOD(GameTable.superBombPower);
			GameView.shipArray[2].shipHit = true;	
		}else{
			GameView.shipArray[2].shipHit = false;
		}
	}
      

	
//weapon power table
if(GameView.shipArray[3].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[3].shipHit = true;	
	}else{
		GameView.shipArray[3].shipHit = false;
	}
}
  


//weapon power table
if(GameView.shipArray[4].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[4].shipHit = true;	
	}else{
		GameView.shipArray[4].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[5].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[5].shipHit = true;	
	}else{
		GameView.shipArray[5].shipHit = false;
	}
}
  


//weapon power table
if(GameView.shipArray[6].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[6].shipHit = true;	
	}else{
		GameView.shipArray[6].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[7].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[7].shipHit = true;	
	}else{
		GameView.shipArray[7].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[8].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[8].shipHit = true;	
	}else{
		GameView.shipArray[8].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[9].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[9].shipHit = true;	
	}else{
		GameView.shipArray[9].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[10].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[10].shipHit = true;	
	}else{
		GameView.shipArray[10].shipHit = false;
	}
}
  


//weapon power table
if(GameView.shipArray[11].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[11].shipHit = true;	
	}else{
		GameView.shipArray[11].shipHit = false;
	}
}
  


//weapon power table
if(GameView.shipArray[12].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[12].shipHit = true;	
	}else{
		GameView.shipArray[12].shipHit = false;
	}
}
  


//weapon power table
if(GameView.shipArray[13].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[13].shipHit = true;	
	}else{
		GameView.shipArray[13].shipHit = false;
	}
}
  



//weapon power table
if(GameView.shipArray[14].shipHitExplode != true){
	if(explode0.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;
	}else if(explode1.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode2.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode3.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;		
	}else if(explode4.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode5.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode6.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode7.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode8.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode9.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode10.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else if(explode11.explodeRect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.superBombPower);
		GameView.shipArray[14].shipHit = true;	
	}else{
		GameView.shipArray[14].shipHit = false;
	}
}
  


//weapon power table
if(Crusher.cGun1HitExplode != true){
	
	if(Crusher.cGun1Rect.intersect(explode0.explodeRect)){
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode1.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode2.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode3.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode4.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode5.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode6.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode7.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode8.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode9.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode10.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;
	}else if(Crusher.cGun1Rect.intersect(explode11.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun1Hit = true;	
	}else{
		Crusher.cGun1Hit = false;
	}
}
	
if(Crusher.cGun2HitExplode != true){
	
	if(Crusher.cGun2Rect.intersect(explode0.explodeRect)){
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode1.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode2.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode3.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode4.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode5.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode6.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode7.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode8.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode9.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode10.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;
	}else if(Crusher.cGun2Rect.intersect(explode11.explodeRect)){			
		setPOD(GameTable.superBombPower);
		Crusher.cGun2Hit = true;	
	}else{
		Crusher.cGun2Hit = false;
	}
}

if(Crusher.cGun3HitExplode != true){

if(Crusher.cGun3Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;
}else if(Crusher.cGun3Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun3Hit = true;	
}else{
Crusher.cGun3Hit = false;
}
}

if(Crusher.cGun4HitExplode != true){

if(Crusher.cGun4Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;
}else if(Crusher.cGun4Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun4Hit = true;	
}else{
Crusher.cGun4Hit = false;
}
}

if(Crusher.cGun5HitExplode != true){

if(Crusher.cGun5Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;
}else if(Crusher.cGun5Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.cGun5Hit = true;	
}else{
Crusher.cGun5Hit = false;
}
}







if(Crusher.sGun1HitExplode != true){

if(Crusher.sGun1Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;
}else if(Crusher.sGun1Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun1Hit = true;	
}else{
Crusher.sGun1Hit = false;
}
}

if(Crusher.sGun2HitExplode != true){

if(Crusher.sGun2Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;
}else if(Crusher.sGun2Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun2Hit = true;	
}else{
Crusher.sGun2Hit = false;
}
}

if(Crusher.sGun3HitExplode != true){

if(Crusher.sGun3Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;
}else if(Crusher.sGun3Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun3Hit = true;	
}else{
Crusher.sGun3Hit = false;
}
}

if(Crusher.sGun4HitExplode != true){

if(Crusher.sGun4Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;
}else if(Crusher.sGun4Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun4Hit = true;	
}else{
Crusher.sGun4Hit = false;
}
}

if(Crusher.sGun5HitExplode != true){

if(Crusher.sGun5Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;
}else if(Crusher.sGun5Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun5Hit = true;	
}else{
Crusher.sGun5Hit = false;
}
}

if(Crusher.sGun6HitExplode != true){

if(Crusher.sGun6Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;
}else if(Crusher.sGun6Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun6Hit = true;	
}else{
Crusher.sGun6Hit = false;
}
}


if(Crusher.sGun7HitExplode != true){

if(Crusher.sGun7Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;
}else if(Crusher.sGun7Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun7Hit = true;	
}else{
Crusher.sGun7Hit = false;
}
}


if(Crusher.sGun8HitExplode != true){

if(Crusher.sGun8Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;
}else if(Crusher.sGun8Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun8Hit = true;	
}else{
Crusher.sGun8Hit = false;
}
}


if(Crusher.sGun9HitExplode != true){

if(Crusher.sGun9Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;
}else if(Crusher.sGun9Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun9Hit = true;	
}else{
Crusher.sGun9Hit = false;
}
}


if(Crusher.sGun10HitExplode != true){

if(Crusher.sGun10Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;
}else if(Crusher.sGun10Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun10Hit = true;	
}else{
Crusher.sGun10Hit = false;
}
}


if(Crusher.sGun11HitExplode != true){

if(Crusher.sGun11Rect.intersect(explode0.explodeRect)){
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode1.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode2.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode3.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode4.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode5.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode6.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode7.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode8.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode9.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode10.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;
}else if(Crusher.sGun11Rect.intersect(explode11.explodeRect)){			
setPOD(GameTable.superBombPower);
Crusher.sGun11Hit = true;	
}else{
Crusher.sGun11Hit = false;
}
}


if(GameView.shipArray[1].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[1].shipX,(int)GameView.shipArray[1].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[1].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[1].shipHit = false; 
	 }
}	

if(GameView.shipArray[2].shipHitExplode != true){	
	if(m22Rect.contains((int)GameView.shipArray[2].shipX,(int)GameView.shipArray[2].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[2].shipHit = true;
		reloadM22 = true;
	}else{
		 GameView.shipArray[2].shipHit = false; 
	 }
	
}

if(GameView.shipArray[3].shipHitExplode != true){	
	if(m22Rect.contains((int)GameView.shipArray[3].shipX,(int)GameView.shipArray[3].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[3].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[3].shipHit = false; 
	 }
}	

if(GameView.shipArray[4].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[4].shipX,(int)GameView.shipArray[4].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[4].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[4].shipHit = false; 
	 }
}

if(GameView.shipArray[5].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[5].shipX,(int)GameView.shipArray[5].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[5].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[5].shipHit = false; 
	 }
}

if(GameView.shipArray[6].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[6].shipX,(int)GameView.shipArray[6].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[6].shipHit = true;
		reloadM22 = true;
	}else{
		 GameView.shipArray[6].shipHit = false; 
	 }
}

if(GameView.shipArray[7].shipHitExplode != true){	
	if(m22Rect.contains((int)GameView.shipArray[7].shipX,(int)GameView.shipArray[7].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[7].shipHit = true;
		reloadM22 = true;
	}else{
		 GameView.shipArray[7].shipHit = false; 
	 }
}
if(GameView.shipArray[8].shipHitExplode != true){	
	if(m22Rect.contains((int)GameView.shipArray[8].shipX,(int)GameView.shipArray[8].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[8].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[8].shipHit = false; 
	 }
}	
if(GameView.shipArray[9].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[9].shipX,(int)GameView.shipArray[9].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[9].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[9].shipHit = false; 
	 }
}	

if(GameView.shipArray[10].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[10].shipX,(int)GameView.shipArray[10].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[10].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[10].shipHit = false; 
	 }
}	

if(GameView.shipArray[11].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[11].shipX,(int)GameView.shipArray[11].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[11].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[11].shipHit = false; 
	 }
}	
	
if(GameView.shipArray[12].shipHitExplode != true){	
	if(m22Rect.contains((int)GameView.shipArray[12].shipX,(int)GameView.shipArray[12].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[12].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[12].shipHit = false; 
	 }
}	

if(GameView.shipArray[13].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[13].shipX,(int)GameView.shipArray[13].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[13].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[13].shipHit = false; 
	 }
}

if(GameView.shipArray[14].shipHitExplode != true){
	if(m22Rect.contains((int)GameView.shipArray[14].shipX,(int)GameView.shipArray[14].shipY)){
		setPOD(GameTable.m22Power);
		GameView.shipArray[14].shipHit = true;
		reloadM22 = true;
	 }else{
		 GameView.shipArray[14].shipHit = false; 
	 }
}	
	
		//reset
		if(BadCoper1.badCoper1Rect.contains((int)m22XPointer, (int)m22YPointer)){
		reloadM22 = true;
		}
	

	return;
	}
	
	
	public void updateBullet(){
		tracerReloadNum += 1;
		rocketReloadNum += 1;
		rocketReloadNum2 += 1;
				
		cursherBulletReloadNum += 1;
		cursherBulletReloadNum1 += 1;
		cursherBulletReloadNum2 += 1;
		
		
		m22SeletorNum++;
		
		m22X = m22XPointer;
		m22Y = m22YPointer;
	
		
		if(m22SeletorNum > 7){
			m22SeletorNum = 0;
		}

				if(rocketName == "smallRocket"){
					
					//Log.i(TAG, "working ");
					//Log.i(TAG, "working " + rocketReloadNum);
					
          		if(rocketReloadNum > 1){
          			rocketReloadNum = 0;
          			showsmallRocketAlpha = 255;
          			smallRocketY -= smallRocketSpeed;
          			smallRocketX = Player.playerPosX + 50;
          			//Log.i(TAG, "Reload r");
          		}else{
          			showsmallRocketAlpha = 0;
          		}
          		
          		
          		
          		if(rocketReloadNum2 > 2){
              		rocketReloadNum2 = 0;
              		showsmallRocket2Alpha = 255;
              		smallRocket2Y -= smallRocketSpeed;
          			smallRocket2X = Player.playerPosX + 10;
              	}else{
              		showsmallRocket2Alpha = 0;	
              	}
      			
      	
          		if(smallRocketY < -0){
          			smallRocketY = Player.playerPosY;
          			smallRocketX = Player.playerPosX + 50;
              	}
      			
      			if(smallRocket2Y < -0){
      				smallRocket2Y = Player.playerPosY;
      				smallRocket2X = Player.playerPosX + 10;
          		}
		
					
				}
		 
      			
    
          		if(bulletName == "single"){
          			showBulletAlpha = 255;
          			bulletY -= bulletSpeed;
          			bulletX = Player.playerPosX + 38;
          			//Log.i(TAG, "tracer ");
          		}else if(bulletName == "double"){
          			showBulletAlpha = 255;
          			mp.start();
          			bulletY -= bulletSpeed;
          			bulletX = Player.playerPosX + 48;
          			bulletReloadNum++;
          			
          			bullet2Y -= bulletSpeed;
          			bullet2X = Player.playerPosX + 28;
          			
          			
          		}else{
          			showBulletAlpha = 0;
          			mp.reset();
          		}
          		
          		
          		
          		 if(bulletName == "single"){
               		if(bulletY < -0){
               			bulletY = Player.playerPosY;
               			bulletX = Player.playerPosX + 38;
               		} 
          		 }else if(bulletName == "double"){
          			if(bulletY < -0){
                  		bulletY = Player.playerPosY;
               			bulletX = Player.playerPosX + 48;
                  	}
          			
          			if(bullet2Y < -0){
              			bullet2Y = Player.playerPosY;
              			bullet2X = Player.playerPosX + 28;
              		}
          			 
          		 }
          		 
           		
      		
      		if(cursherBulletY < -0){
      			reloadcursherBullet = true;
      		}
      		
      		if(cursherBulletY > 480){
      			reloadcursherBullet = true;
      		}
      		
      		if(cursherBulletX > 300){
      			reloadcursherBullet = true;
      		}
      		
      		if(cursherBulletX < -0){
      			reloadcursherBullet = true;
      		}
      		
      		if(reloadcursherBullet){
      			reloadCrusherGun();
      		}

      		
      	
      		if(cursherBulletY1 < -0){
      			reloadcursherBullet = true;
      		}
      		
      		if(cursherBulletY1 > 480){
      			reloadcursherBullet1 = true;
      		}
      		
      		if(cursherBulletX1 > 300){
      			reloadcursherBullet1 = true;
      		}
      		
      		if(cursherBulletX1 < -0){
      			reloadcursherBullet1 = true;
      		}
      		
      		if(reloadcursherBullet1){
      			reloadCrusherGun1();
      		}
      		
      		
      		
      		
      		if(cursherBulletY2 < -0){
      			reloadcursherBullet2 = true;
      		}
      		
      		if(cursherBulletY2 > 480){
      			reloadcursherBullet2 = true;
      		}
      		
      		if(cursherBulletX2 > 300){
      			reloadcursherBullet2 = true;
      		}
      		
      		if(cursherBulletX2 < -0){
      			reloadcursherBullet2 = true;
      		}
      		
      		if(reloadcursherBullet2){
      			reloadCrusherGun2();
      		}
      	  
      		
      		
      		
      		if(reloadcursherBullet == false){
      			
      			if(cursherBulletReloadNum > 2){
          			reloadcursherBullet = false;
      			cursherBulletDist = Math.sqrt(Player.playerPosY - Crusher.cGun5Y); // later
      			showcursherBulletAlpha = 255;
      			cursherBulletX += cursherBulletXSpeed;
          		cursherBulletY += cursherBulletYSpeed;
      			}
      		}
      		
      		if(reloadcursherBullet1 == false){
      			
      			
      			if(cursherBulletReloadNum1 > 3){
          			reloadcursherBullet1 = false;
      			showcursherBulletAlpha1 = 255;
      			cursherBulletX1 += cursherBulletXSpeed1;
          		cursherBulletY1 += cursherBulletYSpeed1;
      			}
      		}
      		
      		if(reloadcursherBullet2 == false){
      		
      		
      			if(cursherBulletReloadNum2 > 4){
          			reloadcursherBullet2 = false;
      			showcursherBulletAlpha2 = 255;
      			cursherBulletX2 += cursherBulletXSpeed2;
          		cursherBulletY2 += cursherBulletYSpeed2;
      			}
      		}
      		
      	
      		if(fireTracer){
      		//tracer
      		showtracerAlpha = 255;
      		tracerX = Player.playerPosX + 45; 
      		tracerY = Player.playerPosY + 38;
      		tracerHeading += 80; // speed around
      		tracerXSpeed = Math.cos(tracerHeading) * tracerSpeed; 
      		tracerYSpeed = Math.sin(tracerHeading) * tracerSpeed;
      		}
      		
      		
      		
      		
      		if(SNESController.AhitIs == true){
          		
          		if(SNESController.fireOne){ 
          			SNESController.fireOne = false; 
          			SNESController.reloadedHellFire = true;
          			showHellfire = false;
          			showHellfireAlpha = 0;
          			hellFire.stop();
          	//	Log.i(TAG, "working ");
          		}
          		
          		
          		
          		if(hellfireY < -0){
          			hellfireY = Player.playerPosY;
          			hellfireX = Player.playerPosX + 34;
              		SNESController.AhitIs = false;
              		SNESController.reloadedHellFire = true;
              		showHellfire = false;
              		showHellfireAlpha = 0;
              		hellFire.stop();
              		//Log.i(TAG, "Reload ");
              	
          		}else{
          			hellFire.start();
          			hellFire.run();
          			showHellfireAlpha = 255;
          			hellfireY -= GameTable.hellfireSpeed;
         			SNESController.reloadedHellFire = false;
          		}
          		
          	
          	}
      		
      		
      		
      		
      		
      		
      		
      		
      		
      		if(SNESController.BhitIs == true){
          		
          		if(SNESController.fireTwo){ 
          			
          			SNESController.fireTwo = false; 
          			SNESController.reloadedSuperBomb = true;
          			explode0.explodeAlpha = 0;
              		explode1.explodeAlpha = 0;
              		explode2.explodeAlpha = 0;
              		explode3.explodeAlpha = 0;
              		explode4.explodeAlpha = 0;
              		explode5.explodeAlpha = 0;
              		explode6.explodeAlpha = 0;
              		explode7.explodeAlpha = 0;
              		explode8.explodeAlpha = 0;
              		explode9.explodeAlpha = 0;
              		explode10.explodeAlpha = 0;
              		explode11.explodeAlpha = 0;
              		
              		explode0.explodeDoDraw = false;
              		explode1.explodeDoDraw = false;
              		explode2.explodeDoDraw = false;
              		explode3.explodeDoDraw = false;
              		explode4.explodeDoDraw = false;
              		explode5.explodeDoDraw = false;
              		explode6.explodeDoDraw = false;
              		explode7.explodeDoDraw = false;
              		explode8.explodeDoDraw = false;
              		explode9.explodeDoDraw = false;
              		explode10.explodeDoDraw = false;
              		explode11.explodeDoDraw = false;
              		
              		explode0.explode.stop();
              		explode1.explode.stop();
              		explode2.explode.stop();
              		explode3.explode.stop();
              		explode4.explode.stop();
              		explode5.explode.stop();
              		explode6.explode.stop();
              		explode7.explode.stop();
              		explode8.explode.stop();
              		explode9.explode.stop();
              		explode10.explode.stop();
              		explode11.explode.stop();
              		
              		explode0.explodeX = explodeOffset;
          			explode0.explodeY = 0;
          			
          			explode1.explodeX = explodeOffset;
          			explode1.explodeY = 0;
          			
          			explode2.explodeX = explodeOffset;
          			explode2.explodeY = 0;
          			
          			explode3.explodeX = explodeOffset;
          			explode3.explodeY = 0;
          			
          			explode4.explodeX = explodeOffset;
          			explode4.explodeY = 0;
          			
          			explode5.explodeX = explodeOffset;
          			explode5.explodeY = 0;
          			
          			explode6.explodeX = explodeOffset;
          			explode6.explodeY = 0;
          			
          			explode7.explodeX = explodeOffset;
          			explode7.explodeY = 0;
          			
          			explode8.explodeX = explodeOffset;
          			explode8.explodeY = 0;
          			
          			explode9.explodeX = explodeOffset; 
          			explode9.explodeY = 0;
          			
          			explode10.explodeX = explodeOffset;
          			explode10.explodeY = 0;
          			
          			explode11.explodeX = explodeOffset;
          			explode11.explodeY = 0;
          		
          			
         
          		}
          		
          	 
          		superBumbTimer -= superBumbNum; 
          		//Log.i(TAG, "superBumbNum " + superBumbTimer);
          		
          		if(superBumbTimer <= 0){
          			superBumbTimer = 255;
              		SNESController.BhitIs = false;
              		SNESController.reloadedSuperBomb = true;
              		explode0.explode.stop();
              		explode1.explode.stop();
              		explode2.explode.stop();
              		explode3.explode.stop();
              		explode4.explode.stop();
              		explode5.explode.stop();
              		explode6.explode.stop();
              		explode7.explode.stop();
              		explode8.explode.stop();
              		explode9.explode.stop();
              		explode10.explode.stop();
              		explode11.explode.stop();
              		
              		explode0.explodeDoDraw = false;
              		explode1.explodeDoDraw = false;
              		explode2.explodeDoDraw = false;
              		explode3.explodeDoDraw = false;
              		explode4.explodeDoDraw = false;
              		explode5.explodeDoDraw = false;
              		explode6.explodeDoDraw = false;
              		explode7.explodeDoDraw = false;
              		explode8.explodeDoDraw = false;
              		explode9.explodeDoDraw = false;
              		explode10.explodeDoDraw = false;
              		explode11.explodeDoDraw = false;
              		
              		explode0.explodeAlpha = 0;
              		explode1.explodeAlpha = 0;
              		explode2.explodeAlpha = 0;
              		explode3.explodeAlpha = 0;
              		explode4.explodeAlpha = 0;
              		explode5.explodeAlpha = 0;
              		explode6.explodeAlpha = 0;
              		explode7.explodeAlpha = 0;
              		explode8.explodeAlpha = 0;
              		explode9.explodeAlpha = 0;
              		explode10.explodeAlpha = 0;
              		explode11.explodeAlpha = 0;
              		
              		explode0.explodeX = explodeOffset;
          			explode0.explodeY = 0;
          			
          			explode1.explodeX = explodeOffset;
          			explode1.explodeY = 0;
          			
          			explode2.explodeX = explodeOffset;
          			explode2.explodeY = 0;
          			
          			explode3.explodeX = explodeOffset;
          			explode3.explodeY = 0;
          			
          			explode4.explodeX = explodeOffset;
          			explode4.explodeY = 0;
          			
          			explode5.explodeX = explodeOffset;
          			explode5.explodeY = 0;
          			
          			explode6.explodeX = explodeOffset;
          			explode6.explodeY = 0;
          			
          			explode7.explodeX = explodeOffset;
          			explode7.explodeY = 0;
          			
          			explode8.explodeX = explodeOffset;
          			explode8.explodeY = 0;
          			
          			explode9.explodeX = explodeOffset; 
          			explode9.explodeY = 0;
          			
          			explode10.explodeX = explodeOffset;
          			explode10.explodeY = 0;
          			
          			explode11.explodeX = explodeOffset;
          			explode11.explodeY = 0;
              	
          		}else{
          		
          			explode0.explodeDoDraw = true;
              		explode1.explodeDoDraw = true;
              		explode2.explodeDoDraw = true;
              		explode3.explodeDoDraw = true;
              		explode4.explodeDoDraw = true;
              		explode5.explodeDoDraw = true;
              		explode6.explodeDoDraw = true;
              		explode7.explodeDoDraw = true;
              		explode8.explodeDoDraw = true;
              		explode9.explodeDoDraw = true;
              		explode10.explodeDoDraw = true;
              		explode11.explodeDoDraw = true;
          			
          			explode0.explode.start();
              		explode1.explode.start();
              		explode2.explode.start();
              		explode3.explode.start();
              		explode4.explode.start();
              		explode5.explode.start();
              		explode6.explode.start();
              		explode7.explode.start();
              		explode8.explode.start();
              		explode9.explode.start();
              		explode10.explode.start();
              		explode11.explode.start();
              		
              		explode0.explode.run();
              		explode1.explode.run();
              		explode2.explode.run();
              		explode3.explode.run();
              		explode4.explode.run();
              		explode5.explode.run();
              		explode6.explode.run();
              		explode7.explode.run();
              		explode8.explode.run();
              		explode9.explode.run();
              		explode10.explode.run();
              		explode11.explode.run();
              		
              		
              		explode0.explodeAlpha = 255;
              		explode1.explodeAlpha = 255;
              		explode2.explodeAlpha = 255;
              		explode3.explodeAlpha = 255;
              		explode4.explodeAlpha = 255;
              		explode5.explodeAlpha = 255;
              		explode6.explodeAlpha = 255;
              		explode7.explodeAlpha = 255;
              		explode8.explodeAlpha = 255;
              		explode9.explodeAlpha = 255;
              		explode10.explodeAlpha = 255;
              		explode11.explodeAlpha = 255;
              		
          			
          			
          			explode0.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode0.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode1.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode1.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode2.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode2.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode3.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode3.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode4.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode4.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode5.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode5.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode6.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode6.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode7.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode7.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode8.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode8.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode9.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode9.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode10.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode10.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          			explode11.explodeX = Math.random() * eXMin + eXMax - explode0.explodeWidth /2;
          			explode11.explodeY = Math.random() * eYMin + eYMax - explode0.explodeHeight /2;
          			
          	
          			SNESController.reloadedSuperBomb = false;
          			
          			
          		}
          		
          	
          	}
      	

	
/*
 	if(Player.playerExplodeIs != true){
 		
 	     if(Player.playerIsHit){
 	    	Player.playerHitNum =  Player.playerHitNum + getPOD(); //% change hit
 				//upDateBossHitNum -= 1 + weaponsPower; // gui
 					//Log.i(TAG, "playerHitNum  " + playerHitNum);
 					if(Player.playerHitNum > Player.playerLife){
 						Player.playerIsHit  = false;
 						Player.playerExplodeIs = true;
 						
 					}
 			
 			}
 	 	
 	 	}
 	   
 	
 	//weapon power table
    if(Player.playerExplodeIs != true){
		if(Player.playerRect.intersect(Bullet.cursherBulletRect)){
			setPOD(GameTable.bulletPower);
			Player.playerIsHit = true;
		}else if(Player.playerRect.intersect(BadCoper1.gBulletRect)){
			setPOD(GameTable.badChoper1bulletPower);
			Player.playerIsHit = true;
		}else{
			Player.playerIsHit = false;
		}
	}
 
    
    if(Player.playersLeft <= 0){
    	GameView.gameOver = true;
    }*/
      		
      		
      		
    		if(badCoperIsHitPow){
    			updatePlayerScore = true;
    	     	if(updatePlayerScore){
    	     	updatePlayerScore = false;
    	    	Player.playerPoints = Player.playerPoints + GameTable.badCoperPoints;
    	    	badCoperIsHitPow = false;
    	     	}
    	    }
    		
    			
    		 if(badCoper1ExplodeIs){
    			 explode0.explodeX = BadCoper1.badCoper1X + BadCoper1.badCoper1Width /2 - 100;
    			 explode0.explodeY = BadCoper1.badCoper1Y + BadCoper1.badCoper1Height /2 - 100;
    			 explode0.explodeDoDraw = true;
    			 explode0.explodeAlpha = 255;
    			 explode0.explode.start();
    			 explode0.explode.run();
    			 BadCoper1.badCoper1Alpha -= GameTable.badCoper1Alpha;
    			 if(BadCoper1.badCoper1Alpha <= 0){
    				 BadCoper1.badCoper1Alpha = 0;
    				 explode0.explodeDoDraw = false;
    				 explode0.explodeAlpha = 0;
    				 explode0.explode.stop();
    				 reSpawn = true;
    			 }
    		 }else{
    			BadCoper1.upDateCoper1();
    		 }  
    		 
    		 
    		 if(reSpawn){
    			 badCoperIsHitPow = true;
    			 badCoper1ExplodeIs = false;
    			 BadCoper1.badCoper1X = 120;
    			 BadCoper1.badCoper1Y = 100;
    			 BadCoper1.badCoper1Alpha = 255;
    			 BadCoper1.badCoper1HitNum = 0; 
    			 BadCoper1.badCoper1ExplodeIs = false;
    			 reSpawn = false;
    		     	
    		 }
    		 
    		
    		
    		
    		
    		
    		if(badCoper1ExplodeIs != true){
    	 		
    		     if(badCoperIsHit){
    		    	 badCoperIsHit  = false;
    		    	 BadCoper1.badCoperIsHit = true;
    		    	
    		    		Log.i(TAG, "Hit.......... bullet class  ");
    		    		
    		    		
    		    		BadCoper1.badCoper1HitNum = BadCoper1.badCoper1HitNum + getPOD(); //% change hit
    		     	Log.i(TAG, "badCoperIsHit.... " + BadCoper1.badCoperIsHit );
    		     	
    						Log.i(TAG, "badCoper1HitNum  " + BadCoper1.badCoper1HitNum);
    						
    						if(BadCoper1.badCoper1HitNum > GameTable.badCoper1Damage){
    							badCoperIsHit  = false;
    							BadCoper1.badCoperIsHit = false;
    							badCoper1ExplodeIs = true;
    							BadCoper1.badCoper1ExplodeIs = true;
    							
    							Log.i(TAG, "badCoper1ExplodeIs .................... " + badCoper1ExplodeIs);
    						
    						}
    				
    				}else{
    					 BadCoper1.badCoperIsHit = false;
    				}
    		 	}
    
    		

      		if(GameView.shipArray[1].shipHit){
      			GameView.shipArray[1].shipHitNum = GameView.shipArray[1].shipHitNum + getPOD();
      				if(GameView.shipArray[1].whatKindOfShip == 0){
      					if(GameView.shipArray[1].shipHitNum > GameTable.ship0Damage){
      						GameView.shipArray[1].shipHitExplode = true;
      						GameView.shipArray[1].shipHit = false;
      					}
      				}else if(GameView.shipArray[1].whatKindOfShip == 1){
      					if(GameView.shipArray[1].shipHitNum > GameTable.ship1Damage){
      						GameView.shipArray[1].shipHitExplode = true;
      						GameView.shipArray[1].shipHit = false;
      					}
      					
      				}
      			
      			}

      		if(GameView.shipArray[2].shipHit){
      			GameView.shipArray[2].shipHitNum = GameView.shipArray[2].shipHitNum + getPOD();
      			if(GameView.shipArray[2].whatKindOfShip == 0){
      				if(GameView.shipArray[2].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[2].shipHitExplode = true;
      					GameView.shipArray[2].shipHit = false;
      				}
      			}else if(GameView.shipArray[2].whatKindOfShip == 1){
      				if(GameView.shipArray[2].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[2].shipHitExplode = true;
      					GameView.shipArray[2].shipHit = false;
      				}
      				
      			}
      		
      		}
      		if(GameView.shipArray[3].shipHit){
      			GameView.shipArray[3].shipHitNum = GameView.shipArray[3].shipHitNum + getPOD();
      			if(GameView.shipArray[3].whatKindOfShip == 0){
      				if(GameView.shipArray[3].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[3].shipHitExplode = true;
      					GameView.shipArray[3].shipHit = false;
      				}
      			}else if(GameView.shipArray[3].whatKindOfShip == 1){
      				if(GameView.shipArray[3].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[3].shipHitExplode = true;
      					GameView.shipArray[3].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[4].shipHit){
      			GameView.shipArray[4].shipHitNum = GameView.shipArray[4].shipHitNum + getPOD();
      			if(GameView.shipArray[4].whatKindOfShip == 0){
      				if(GameView.shipArray[4].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[4].shipHitExplode = true;
      					GameView.shipArray[4].shipHit = false;
      				}
      			}else if(GameView.shipArray[4].whatKindOfShip == 1){
      				if(GameView.shipArray[4].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[4].shipHitExplode = true;
      					GameView.shipArray[4].shipHit = false;
      				}
      				
      			}

      		}


      		if(GameView.shipArray[5].shipHit){
      			GameView.shipArray[5].shipHitNum = GameView.shipArray[5].shipHitNum + getPOD();
      			if(GameView.shipArray[5].whatKindOfShip == 0){
      				if(GameView.shipArray[5].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[5].shipHitExplode = true;
      					GameView.shipArray[5].shipHit = false;
      				}
      			}else if(GameView.shipArray[5].whatKindOfShip == 1){
      				if(GameView.shipArray[5].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[5].shipHitExplode = true;
      					GameView.shipArray[5].shipHit = false;
      				}
      				
      			}

      		}


      		if(GameView.shipArray[6].shipHit){
      			GameView.shipArray[6].shipHitNum = GameView.shipArray[6].shipHitNum + getPOD();
      			if(GameView.shipArray[6].whatKindOfShip == 0){
      				if(GameView.shipArray[6].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[6].shipHitExplode = true;
      					GameView.shipArray[6].shipHit = false;
      				}
      			}else if(GameView.shipArray[6].whatKindOfShip == 1){
      				if(GameView.shipArray[6].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[6].shipHitExplode = true;
      					GameView.shipArray[6].shipHit = false;
      				}
      				
      			}

      		}
      		if(GameView.shipArray[7].shipHit){
      			GameView.shipArray[7].shipHitNum = GameView.shipArray[7].shipHitNum + getPOD();
      			if(GameView.shipArray[7].whatKindOfShip == 0){
      				if(GameView.shipArray[7].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[7].shipHitExplode = true;
      					GameView.shipArray[7].shipHit = false;
      				}
      			}else if(GameView.shipArray[7].whatKindOfShip == 1){
      				if(GameView.shipArray[7].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[7].shipHitExplode = true;
      					GameView.shipArray[7].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[8].shipHit){
      			GameView.shipArray[8].shipHitNum = GameView.shipArray[8].shipHitNum + getPOD();
      			if(GameView.shipArray[8].whatKindOfShip == 0){
      				if(GameView.shipArray[8].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[8].shipHitExplode = true;
      					GameView.shipArray[8].shipHit = false;
      				}
      			}else if(GameView.shipArray[8].whatKindOfShip == 1){
      				if(GameView.shipArray[8].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[8].shipHitExplode = true;
      					GameView.shipArray[8].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[9].shipHit){
      			GameView.shipArray[9].shipHitNum = GameView.shipArray[9].shipHitNum + getPOD();
      			if(GameView.shipArray[9].whatKindOfShip == 0){
      				if(GameView.shipArray[9].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[9].shipHitExplode = true;
      					GameView.shipArray[9].shipHit = false;
      				}
      			}else if(GameView.shipArray[9].whatKindOfShip == 1){
      				if(GameView.shipArray[9].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[9].shipHitExplode = true;
      					GameView.shipArray[9].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[10].shipHit){
      			GameView.shipArray[10].shipHitNum = GameView.shipArray[10].shipHitNum + getPOD();
      			if(GameView.shipArray[10].whatKindOfShip == 0){
      				if(GameView.shipArray[10].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[10].shipHitExplode = true;
      					GameView.shipArray[10].shipHit = false;
      				}
      			}else if(GameView.shipArray[10].whatKindOfShip == 1){
      				if(GameView.shipArray[10].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[10].shipHitExplode = true;
      					GameView.shipArray[10].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[11].shipHit){
      			GameView.shipArray[11].shipHitNum = GameView.shipArray[11].shipHitNum + getPOD();
      			if(GameView.shipArray[11].whatKindOfShip == 0){
      				if(GameView.shipArray[11].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[11].shipHitExplode = true;
      					GameView.shipArray[11].shipHit = false;
      				}
      			}else if(GameView.shipArray[11].whatKindOfShip == 1){
      				if(GameView.shipArray[11].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[11].shipHitExplode = true;
      					GameView.shipArray[11].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[12].shipHit){
      			GameView.shipArray[12].shipHitNum = GameView.shipArray[12].shipHitNum + getPOD();
      			if(GameView.shipArray[12].whatKindOfShip == 0){
      				if(GameView.shipArray[12].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[12].shipHitExplode = true;
      					GameView.shipArray[12].shipHit = false;
      				}
      			}else if(GameView.shipArray[12].whatKindOfShip == 1){
      				if(GameView.shipArray[12].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[12].shipHitExplode = true;
      					GameView.shipArray[12].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[13].shipHit){
      			GameView.shipArray[13].shipHitNum = GameView.shipArray[14].shipHitNum + getPOD();
      			if(GameView.shipArray[13].whatKindOfShip == 0){
      				if(GameView.shipArray[13].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[13].shipHitExplode = true;
      					GameView.shipArray[13].shipHit = false;
      				}
      			}else if(GameView.shipArray[13].whatKindOfShip == 1){
      				if(GameView.shipArray[13].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[13].shipHitExplode = true;
      					GameView.shipArray[13].shipHit = false;
      				}
      				
      			}

      		}

      		if(GameView.shipArray[14].shipHit){
      			GameView.shipArray[14].shipHitNum = GameView.shipArray[14].shipHitNum + getPOD();
      			if(GameView.shipArray[14].whatKindOfShip == 0){
      				if(GameView.shipArray[14].shipHitNum > GameTable.ship0Damage){
      					GameView.shipArray[14].shipHitExplode = true;
      					GameView.shipArray[14].shipHit = false;
      				}
      			}else if(GameView.shipArray[14].whatKindOfShip == 1){
      				if(GameView.shipArray[14].shipHitNum > GameTable.ship1Damage){
      					GameView.shipArray[14].shipHitExplode = true;
      					GameView.shipArray[14].shipHit = false;
      				}
      				
      			}

      		}
    
      		
      		//fireSel = 1;
      		
      		for(int S = 0; S < miniBArray.length; S++){
      			
      			//Log.i(TAG, "miniBArray " + S);
      		   
      			if(miniBArray[S].gBulletY == 24.0){
      				/*switch(S){
      				
      				case 0:
      					 miniBArray[0].notInFlight = true; 
      					 //Log.i(TAG, "miniBArray 0 Wating");
      				    break;
      				
      				case 1:
      					miniBArray[1].notInFlight = true; 
      					//Log.i(TAG, "miniBArray 1 Wating");
          				break;
          				
      				case 2:
      					miniBArray[2].notInFlight = true; 
      					//Log.i(TAG, "miniBArray 2 Wating");
          				break;
          				
          			case 3:
          				miniBArray[3].notInFlight = true; 
          				//Log.i(TAG, "miniBArray 3 Wating");	
              			break;	
      				
      				}
      				*/
      				
      				
      			}
      		
      			
      			//for(fireSel = 0; fireSel < S; fireSel++){
          			
      			//}
      			
      			if(fireSel == S){
      			//Log.i(TAG, "miniBArray " + S);
      			//Log.i(TAG, "fireSel " + fireSel);
      			}
      			
      			if(miniBArray[S].gBulletY != 24.0){
  					miniBArray[S].inFlight = true; 
  					//Log.i(TAG, "inFlight " + S );
  				} 
      			
      			if(miniBArray[S].gBulletY == 24.0){
      				miniBArray[S].inFlight = false;
      				//Log.i(TAG, " " + S + "in flight false");
      				
      				
      			}
      			
  				
      			
      			
      		}
      		
    
      		if(time > 120){
    			time = 1;
    			fireSel++;
    		}else{
    			time += 30;	
    		}
      		
      		/*if(fireSel >= 6 && miniBArray[3].inFlight == false){
      			fireSel = 0;
      		}*/
      		if(fireSel >= 120){
      			fireSel = 0;
      		}
      
        
       //Log.i(TAG, "clock " + time);
       // Log.i(TAG, "FIRE " + FIRE);
        
		if(fireSel >= 1){
		miniB.updateGBullet();
		}
		if(fireSel >= 2){
		miniB1.updateGBullet();
		}
		if(fireSel >= 3){
		miniB2.updateGBullet();
		}
		if(fireSel >= 4){	
		//miniB3.updateGBullet();
		}
	
		/*//if in flight stay in until destroyed
			if(miniBArray[0].inFlight == true){
				miniB.updateGBullet();
			}
			if(miniBArray[1].inFlight == true){
				miniB.updateGBullet();
			}
			if(miniBArray[2].inFlight == true){
				miniB.updateGBullet();
			}
			if(miniBArray[3].inFlight == true){
				miniB.updateGBullet();
			}
		*/
		
		
		
		
		
 
      	 
      	m22ReloadNum -= 0.1;
      	if(m22ReloadNum < 0){
      		fireM22 = true; 
			m22ReloadNum = GameTable.m22ReloadNumTime;  
		}
      	
      	
      
      	m22DX = (GameMain.playerTargetX + Player.playerTargetWidth /2)- (m22XPointer + m22Width /2);
      	m22DY = (GameMain.playerTargetY + Player.playerTargetHeight /2) - (m22YPointer + m22Height /2);
    	m22AngleRot = Math.atan2(m22DX,m22DY);
    	m22AngleHead = m22AngleRot * 180 / Math.PI;
  		
  		
		m22Heading = Math.atan2(GameMain.playerTargetY - Player.playerPosY ,GameMain.playerTargetX - Player.playerPosX);
		m22SpeedX = Math.cos(m22Heading) * m22Speed; 
		m22SpeedY = Math.sin(m22Heading) * m22Speed;
		
		
		//fireM22
      	if(Player.playerTargetVisible == 255){
  			m22XPointer += m22SpeedX;
  			m22YPointer += m22SpeedY; 
  			reloadM22 = false;
  			m22Speed += GameTable.m22SpeedSetting;
  			
  			/*m22SmokeX = m22XPointer;
  			m22SmokeY = m22YPointer;
  			m22SmokeAlpha = m22SmokeAlphaNum;
  			m22SmokeAlpha -= 5;
  			if(m22SmokeAlpha < 0){
  				m22SmokeAlpha = 0;
  			}*/
  		
  		}else{
  			//m22Speed = 0.2;
  			//m22SmokeAlpha = 0;
  			m22XPointer = (int)Player.playerPosX + (int)Player.playerWidth /2 -10;
  			m22YPointer = (int)Player.playerPosY + (int)Player.playerHeight /2 + -10;
  			
  			m22Rot = m22Angle * m22radians;
 			m22Angle = Math.atan2(GameMain.playerTargetY - Player.playerPosY ,GameMain.playerTargetX - Player.playerPosX);
  	   		m22Heading = (m22Rot * 360 / Math.PI);
  	   	}
      	
      	
      
      	
      		if(m22YPointer < -0){
	  			reloadM22 = true;
	  		}
	  		
	  		if(m22YPointer > 480){
	  			reloadM22 = true;
	  		}
	  		
	  		if(m22XPointer > 300){
	  			reloadM22 = true;
	  		}
	  		
	  		if(m22XPointer < -0){
	  			reloadM22 = true;
	  		}
	  		
	  		
	  		if(reloadM22 == true){
	  			fireM22 = false;
	  			reloadM22Missle();
	  			reloadM22 = false;
	  			
	  		}
	  		
	  		
	  		//clock = Math.PI/360;
	 		//clockRot = clockHeading * clock;
	 		//clockHeading = (clockRot * 360 / Math.PI);
	  		
	  		//System.currentTimeMillis();
			//clockXSpeed = Math.cos(clockHeading) * clockSpeed; 
			//clockYSpeed = Math.sin(clockHeading) * clockSpeed;
			//clockRot = Math.atan2(clockX, clockY);
	 	
	  		
			
	
	 return;	
	}
	
	
	
	
	public void reloadCrusherGun(){
		reloadcursherBullet = false;
		
			showcursherBulletAlpha = 0;
			cursherBulletX = Crusher.cGun5X + Crusher.cGun5Width /2;
			cursherBulletY = Crusher.cGun5Y + Crusher.cGun5Height /2;
			cursherBulletHeading = Math.atan2(Player.playerPosY - Crusher.cGun5Y,Player.playerPosX - Crusher.cGun5X);
  			cursherBulletXSpeed = Math.cos(cursherBulletHeading) * cursherBulletSpeed; 
  			cursherBulletYSpeed = Math.sin(cursherBulletHeading) * cursherBulletSpeed;
  	
  		 return;	
	}
	
	public void reloadCrusherGun1(){
		reloadcursherBullet1 = false;
			showcursherBulletAlpha1 = 0;
			cursherBulletX1 = Crusher.cGun5X + Crusher.cGun5Width /2;
			cursherBulletY1 = Crusher.cGun5Y + Crusher.cGun5Height /2;
			
			cursherBulletHeading = Math.atan2(Player.playerPosY - Crusher.cGun5Y,Player.playerPosX - Crusher.cGun5X);
		
  			cursherBulletXSpeed1 = Math.cos(cursherBulletHeading) * cursherBulletSpeed; 
  			cursherBulletYSpeed1 = Math.sin(cursherBulletHeading) * cursherBulletSpeed;
	
  			//Log.i(TAG, "Reload1 ");
  		 return;	
	}
	
	public void reloadCrusherGun2(){
		reloadcursherBullet2 = false;
			showcursherBulletAlpha2 = 0;
			cursherBulletX2 = Crusher.cGun5X + Crusher.cGun5Width /2;
			cursherBulletY2 = Crusher.cGun5Y + Crusher.cGun5Height /2;
		
			cursherBulletHeading = Math.atan2(Player.playerPosY - Crusher.cGun5Y,Player.playerPosX - Crusher.cGun5X);
	
  			cursherBulletXSpeed2 = Math.cos(cursherBulletHeading) * cursherBulletSpeed; 
  			cursherBulletYSpeed2 = Math.sin(cursherBulletHeading) * cursherBulletSpeed;
  			
  			//Log.i(TAG, "Reload2 ");
  		 return;	
	}
	
	
	
	public void reloadM22Missle(){
		//reloadM22 = false;
		m22Speed = 0.2;
		m22XPointer = Player.playerPosX + Player.playerWidth /2 - 10;
		m22YPointer = Player.playerPosY + Player.playerHeight /2 + -10;
		
		
	    m22Heading = Math.atan2(GameMain.playerTargetY - Player.playerPosY ,GameMain.playerTargetX - Player.playerPosX);
		m22SpeedX = Math.cos(m22Heading) * m22Speed; 
		m22SpeedY = Math.sin(m22Heading) * m22Speed;
		
		
  		
  	return;	
	}
	
	

	//power of destruction 
	public void setPOD(int wep){
		
	//	Log.i(TAG, "weaponsDamage   " + weaponsDamage );
		
		switch(wep){
		case 1 :
			weaponsDamage = wep; 
		break;
		
		case 100 :
			weaponsDamage = wep; 
		break;
		
		case 200 :
			weaponsDamage = wep; 
		break;	
		
		}
		 
	return;		
	}

	public int getPOD(){
	return weaponsDamage; 
	}
	
}
