package com.TP;


public class GameTable {
	
	
	
	public final static double badCoper1Gravity = 8.58;
	public final static double badCoper1friction = 0.98;
	
	public final static int cGun1Damage = 100;
	public final static int ship0Damage = 8800;//cruser
	public final static int ship1Damage = 2024;//pt
	
	public final static int ship0DamageTimes = 23;
	public final static int ship1DamageTimes = 100;
	
	public final static int badCoper1Damage = 440;
	public final static int badCoper1DamageTimes = 5;
	
	public final static int ship0Points = 50; 
	public final static int ship1Points = 100; 
	public final static int badCoperPoints = 300; 
	
	public final static int playerLife = 3520;
	public final static int playerDamageTimes = 40;

	
	//setPOD ///
	public final static int bulletPower = 1;
	public final static int smallRocket2Power = 2;
	public final static int smallRocketPower = 2;
	public final static int tracerPower = 3;
	public final static int hellfirePower = 300;
	public final static int superBombPower = 0; //= 100;
	public final static int m22Power = 10000;
	public final static int badChoper1bulletPower = 1;
	public final static int towPower = 40;
	public final static int cursherBulletPower = 100;
	
	
	public final static double hellfireSpeed = 8;
	//bad
	public final static int badCoper1AlphaTimer = 30;
	public final static int badCoper1Timer = 30;
	public final static int playerAlpha = 120;
	
	//speed
	public final static double m22SpeedSetting = 0.88;
	public final static double m22ReloadNumTime = 1.0;
	
	
	
	
}
